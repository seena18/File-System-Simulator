#ifndef _tinyFS_h
#define _tinyFS_h

#define BLOCKSIZE            256
#define DEFAULT_DISK_SIZE    10240
#define DEFAULT_DISK_NAME    "tinyFSDisk.dsk"

#endif /* _tinyFS_h */
